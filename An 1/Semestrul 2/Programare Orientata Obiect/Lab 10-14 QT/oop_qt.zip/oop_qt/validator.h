#pragma once
#include <string>
#include "locatar.h"
using std::string;


class validator
{
public:
    static void validate_locatar(const Locatar& locatar);
};