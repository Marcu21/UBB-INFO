#pragma once
#include <stdlib.h>

int adauga(Repository* MASINI, char* numar, char* categorie, char* model);
int actualizare(Repository* MASINI, char* numar, char* categorie_noua, char* model_nou);
Repository* vizualizare_categorie(Repository* MASINI, char* categorie);
Repository* vizualizare_model(Repository* MASINI, char* model);
int comparator_categorie_crescator(const Masina* a, const Masina* b);
int comparator_categorie_descrescator(const Masina* a, const Masina* b);
int comparator_model_crescator(const Masina* a, const Masina* b);
int comparator_model_descrescator(const Masina* a, const Masina* b);
void sortare(Repository* MASINI, int (*comparator)(const Masina*, const Masina*));
/*
void sortare_categorie_descrescator(Repository* MASINI);
void sortare_model_crescator(Repository* MASINI);
void sortare_model_descrescator(Repository* MASINI);
 */
int inchiriere(Repository* MASINI, char* numar);
int returnare(Repository* MASINI, char* numar);
