void test_validate_masina();
void test_adauga();
void test_actualizare();
void ruleaza_toate_testele();