#include <stdlib.h>
#include <string.h>
#include "Repo.h"

void init(Repository* masini) {
    //Initializeaza lista de masini
    masini->lungime = 0;
}

Repository creeaza_vid() {
    //Initializeaza o lista de masini vida
    Repository m;
    m.capacitate = 2;
    m.masini = malloc(sizeof(Masina) * m.capacitate);
    m.lungime = 0;
    return m;
}

void distruge(Repository* masini) {
    //Distruge lista de masini
    for (int i = 0; i < masini->lungime; i++) {
        distruge_masina(&masini->masini[i]);
    }
    free(masini->masini);
    masini->lungime = 0;
    masini->capacitate = 0;
}

void adaugareR(Repository* MASINI, Masina masina) {
    //Adauga o masina in lista de masini
    if (MASINI->lungime == MASINI->capacitate) {
        MASINI->capacitate *= 2;
        Masina* masini_noi = malloc(sizeof(Masina) * MASINI->capacitate);
        for (int i = 0; i < MASINI->lungime; i++) {
            masini_noi[i] = MASINI->masini[i];
        }
        free(MASINI->masini);
        MASINI->masini = masini_noi;
    }
    MASINI->masini[MASINI->lungime++] = masina;
}

void actualizamR(Repository* MASINI, char* numar, char* categorie_noua, char* model_nou) {
    //Actualizeaza o masina din lista de masini,cu conditia ca numarul de inmatriculare sa fie existent
    for (int i = 0; i < MASINI->lungime; i++) {
        if (strcmp(MASINI->masini[i].numar, numar) == 0) {
            strcpy(MASINI->masini[i].categorie, categorie_noua);
            strcpy(MASINI->masini[i].model, model_nou);
        }
    }
}