#include <stdio.h>
#include <assert.h>
#include <string.h>
#include "Repo.h"
#include "validator.h"
#include "service.h"


void test_domain() {
    //Testeaza partea de domain
    Masina m = creare_masina("sm21mrc","sport","coupe");
    assert(strcmp(get_numar(&m), "sm21mrc") == 0);
    assert(strcmp(get_categorie(&m), "sport") == 0);
    assert(strcmp(get_model(&m), "coupe") == 0);
    set_numar(&m, "sm80mrc");
    assert(strcmp(get_numar(&m), "sm80mrc") == 0);
    set_categorie(&m, "suv");
    assert(strcmp(get_categorie(&m), "suv") == 0);
    set_model(&m, "gle");
    assert(strcmp(get_model(&m), "gle") == 0);
    distruge_masina(&m);
    printf("Testul pentru domain a trecut cu succes.\n");
}

void test_repo() {
    //Testeaza partea de repo
    Repository masini;
    masini = creeaza_vid();
    assert(masini.lungime == 0);
    Masina m = creare_masina("sm21mrc","sport","coupe");
    adaugareR(&masini, m);
    assert(masini.lungime == 1);
    assert(strcmp(get_numar(&masini.masini[0]), "sm21mrc") == 0);
    assert(strcmp(get_categorie(&masini.masini[0]), "sport") == 0);
    assert(strcmp(get_model(&masini.masini[0]), "coupe") == 0);
    actualizamR(&masini, "sm21mrc", "suv", "gle");
    assert(strcmp(get_numar(&masini.masini[0]), "sm21mrc") == 0);
    assert(strcmp(get_categorie(&masini.masini[0]), "suv") == 0);
    assert(strcmp(get_model(&masini.masini[0]), "gle") == 0);
    distruge(&masini);
    printf("Testul pentru repo a trecut cu succes.\n");
}

void test_validate_masina() {
    //Testeaza partea de validare
    assert(validate_masina("AB123CD", "Sedan", "Toyota") == 1);

    assert(validate_masina("A1#23CD", "Sedan", "Toyota") == 0);

    assert(validate_masina("AB123CD", "Sedan2", "Toyota") == 0);

    assert(validate_masina("AB123CD", "Sedan", "Toyota!") == 0);

    assert(validate_masina("", "", "") == 0);

    printf("Testul pentru validare a trecut cu succes.\n");
}

void test_creeaza_distruge() {
    Masina m = creare_masina("sm21mrc","sport","coupe");
    assert(strcmp(m.numar,"sm21mrc")==0);
    assert(strcmp(m.categorie,"sport")==0);
    assert(strcmp(m.model,"coupe")==0);

    distruge_masina(&m);
    assert(m.inchiriata==-100);
}

void test_adauga() {
    //Testeaza partea de adaugare
    Repository MASINI;
    MASINI = creeaza_vid();
    adauga(&MASINI, "AB123CD", "Sedan", "Toyota");

    assert(MASINI.lungime == 1);
    adauga(&MASINI, "", "!Sedan", "21Toyota");
    assert(MASINI.lungime == 1);
    distruge(&MASINI);
    printf("Testul pentru adaugare a trecut cu succes.\n");
}

void test_actualizare() {
        //Testeaza partea de actualizare
        Repository MASINI;
        MASINI = creeaza_vid();
        Masina masina1 = creare_masina("AB123CD", "Sedan", "Toyota");
        assert(strcmp(get_numar(&masina1), "AB123CD") == 0);
        assert(strcmp(get_categorie(&masina1), "Sedan") == 0);
        assert(strcmp(get_model(&masina1), "Toyota") == 0);
        adaugareR(&MASINI, masina1);
        actualizare(&MASINI, "AB123CD", "!Coupe", "");
        actualizare(&MASINI, "AB123CD", "Coupe", "Honda");

        assert(strcmp(MASINI.masini[0].categorie, "Coupe") == 0);
        distruge(&MASINI);
        printf("Testul pentru actualizare a trecut cu succes.\n");
}

void test_vizualizare() {
    //Testeaza partea de vizualizare
    Repository MASINI;
    MASINI = creeaza_vid();
    adauga(&MASINI, "AB123CD", "Sedan", "Toyota");
    adauga(&MASINI, "XYZ987", "Hatchback", "Honda");
    adauga(&MASINI, "BCD456", "Sedan", "Nissan");

    Repository* masini2 = vizualizare_categorie(&MASINI, "Sedan");
    assert(masini2->lungime == 2);
    assert(strcmp(get_categorie(&masini2->masini[0]), "Sedan") == 0);
    assert(strcmp(get_categorie(&masini2->masini[1]), "Sedan") == 0);
    free(masini2->masini);
    free(masini2);
    masini2 = vizualizare_model(&MASINI, "Honda");
    assert(masini2->lungime == 1);
    assert(strcmp(get_model(&masini2->masini[0]), "Honda") == 0);
    free(masini2->masini);
    free(masini2);
    distruge(&MASINI);
    printf("Testul pentru vizualizare a trecut cu succes.\n");
}



void test_inchiriere_returnare() {
    //Testeaza partea de inchiriere/returnare
    Repository masini;
    masini = creeaza_vid();
    adauga(&masini, "AB123CD", "Sedan", "Toyota");

    assert(inchiriere(&masini, "AB123CD") == 1);

    assert(inchiriere(&masini, "XYZ987") == -1);

    assert(inchiriere(&masini, "AB123CD") == 0);


    assert(returnare(&masini, "AB123CD") == 1);

    assert(returnare(&masini, "AB123CD") == 0);

    assert(returnare(&masini, "XYZ987") == -1);
    distruge(&masini);
    printf("Testul pentru inchiriere si returnare a trecut cu succes.\n");
}

void test_sortare_categorie_crescator() {
    //Testeaza partea de sortare categorie crescator
    Repository masini;
    masini = creeaza_vid();
    adauga(&masini, "AB123CD", "Sedan", "Toyota");
    adauga(&masini, "XYZ987", "Hatchback", "Honda");
    adauga(&masini, "BCD456", "Sedan", "Nissan");

    sortare(&masini, comparator_categorie_crescator);

    assert(strcmp(get_categorie(&masini.masini[0]), "Hatchback") == 0);
    assert(strcmp(get_categorie(&masini.masini[1]), "Sedan") == 0);
    assert(strcmp(get_categorie(&masini.masini[2]), "Sedan") == 0);
    distruge(&masini);
}

void test_sortare_categorie_descrescator() {
    //Testeaza partea de sortare categorie descrescator
    Repository masini;
    masini = creeaza_vid();
    adauga(&masini, "AB123CD", "Sedan", "Toyota");
    adauga(&masini, "XYZ987", "Hatchback", "Honda");
    adauga(&masini, "BCD456", "Sedan", "Nissan");

    sortare(&masini, comparator_categorie_descrescator);

    assert(strcmp(get_categorie(&masini.masini[0]), "Sedan") == 0);
    assert(strcmp(get_categorie(&masini.masini[1]), "Sedan") == 0);
    assert(strcmp(get_categorie(&masini.masini[2]), "Hatchback") == 0);
    distruge(&masini);
}

void test_sortare_model_crescator() {
    //Testeaza partea de sortare model crescator
    Repository masini;
    masini = creeaza_vid();
    adauga(&masini, "AB123CD", "Sedan", "Toyota");
    adauga(&masini, "XYZ987", "Hatchback", "Honda");
    adauga(&masini, "BCD456", "Sedan", "Nissan");

    sortare(&masini, comparator_model_crescator);

    assert(strcmp(get_model(&masini.masini[0]), "Honda") == 0);
    assert(strcmp(get_model(&masini.masini[1]), "Nissan") == 0);
    assert(strcmp(get_model(&masini.masini[2]), "Toyota") == 0);
    distruge(&masini);
}

void test_sortare_model_descrescator() {
    //Testeaza partea de sortare model descrescator
    Repository masini;
    masini = creeaza_vid();
    adauga(&masini, "AB123CD", "Sedan", "Toyota");
    adauga(&masini, "XYZ987", "Hatchback", "Honda");
    adauga(&masini, "BCD456", "Sedan", "Nissan");

    sortare(&masini, comparator_model_descrescator);

    assert(strcmp(get_model(&masini.masini[0]), "Toyota") == 0);
    assert(strcmp(get_model(&masini.masini[1]), "Nissan") == 0);
    assert(strcmp(get_model(&masini.masini[2]), "Honda") == 0);
    distruge(&masini);
    printf("Testul pentru sortare a trecut cu succes.\n");
}

void ruleaza_toate_testele() {
    //Ruleaza toate testele
    test_domain();
    test_repo();
    test_validate_masina();
    test_adauga();
    test_actualizare();
    test_vizualizare();
    test_inchiriere_returnare();
    test_sortare_categorie_crescator();
    test_sortare_categorie_descrescator();
    test_sortare_model_crescator();
    test_sortare_model_descrescator();
    test_creeaza_distruge();
}

