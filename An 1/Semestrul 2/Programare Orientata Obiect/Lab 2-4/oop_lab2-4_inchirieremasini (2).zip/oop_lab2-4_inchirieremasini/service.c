#include <stdlib.h>
#include <string.h>
#include "repo.h"
#include "validator.h"


int adauga(Repository* MASINI, char* numar, char* categorie, char* model) {
    //Adauga o masina noua daca este valida
    Masina masina_noua = creare_masina(numar,categorie,model);
    if (!validate_masina(numar, categorie, model)) {
        distruge_masina(&masina_noua);
        return -1;
    }
    masina_noua.inchiriata = 0;
    adaugareR(MASINI, masina_noua);
    return 1;
}


int actualizare(Repository* MASINI, char* numar, char* categorie_noua, char* model_nou) {
    //Modifica categoria si modelul (daca sunt valide) pentru o masina identificata prin numar de inmatriculare
    if (!validate_masina(numar, categorie_noua, model_nou)) {
        return -1;
    }

    actualizamR(MASINI, numar, categorie_noua, model_nou);
    return 1;
}

Repository* vizualizare_categorie(Repository* MASINI, char* categorie) {
    // Returneaza toate masinile dintr-o anumită categorie
    Repository* masini2 = (Repository*)malloc(sizeof(Repository));
    *masini2 = creeaza_vid();

    for (int i = 0; i < MASINI->lungime; i++) {
        if (strcmp(get_categorie(&MASINI->masini[i]), categorie) == 0) {
            adaugareR(masini2, MASINI->masini[i]);
        }
    }

    return masini2;
}


Repository* vizualizare_model(Repository* MASINI, char* model) {
    // Returneaza toate masinile dintr-un anumit model
    Repository* masini2 = (Repository*)malloc(sizeof(Repository));
    *masini2 = creeaza_vid();

    for (int i = 0; i < MASINI->lungime; i++) {
        if (strcmp(get_model(&MASINI->masini[i]), model) == 0) {
            adaugareR(masini2, MASINI->masini[i]);
        }
    }

    return masini2;
}

int comparator_categorie_crescator(const Masina* a, const Masina* b) {
    //Returneaza 1 daca cele 2 masini au categoria in ordine crescatoare, 0 altfel
    return strcmp(a->categorie, b->categorie) > 0;
}

int comparator_categorie_descrescator(const Masina* a, const Masina* b) {
    //Returneaza 1 daca cele 2 masini au categoria in ordine descrescatoare, 0 altfel
    return strcmp(a->categorie, b->categorie) < 0;
}

void sortare(Repository* MASINI, int (*comparator)(const Masina*, const Masina*)) {
    //Sorteaza masinile in functie de comparator
    int n = MASINI->lungime;

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if(comparator(&MASINI->masini[j], &MASINI->masini[j+1]))
            {
                Masina aux = MASINI->masini[j];
                MASINI->masini[j] = MASINI->masini[j + 1];
                MASINI->masini[j + 1] = aux;
            }
        }
    }
}


/*
void sortare_categorie_descrescator(Repository* MASINI) {
    //Sorteaza masinile descrescator dupa categorie
    int n = MASINI->lungime;

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (strcmp(get_categorie(&MASINI->masini[j]), get_categorie(&MASINI->masini[j + 1])) < 0) {
                Masina aux = MASINI->masini[j];
                MASINI->masini[j] = MASINI->masini[j + 1];
                MASINI->masini[j + 1] = aux;
            }
        }
    }
}
*/

int comparator_model_crescator(const Masina* a, const Masina* b) {
    //Returneaza 1 daca cele 2 masini au modelul in ordine crescatoare, 0 altfel
    return strcmp(a->model, b->model) > 0;
}

int comparator_model_descrescator(const Masina* a, const Masina* b) {
    //Returneaza 1 daca cele 2 masini au modelul in ordine descrescatoare, 0 altfel
    return strcmp(a->model, b->model) < 0;
}
/*
void sortare_model_crescator(Repository* MASINI, int (*comparator)(const Masina*, const Masina*)) {
    //Sorteaza masinile crescator dupa model
    int n = MASINI->lungime;

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (strcmp(get_model(&MASINI->masini[j]), get_model(&MASINI->masini[j + 1])) > 0) {
                Masina aux = MASINI->masini[j];
                MASINI->masini[j] = MASINI->masini[j + 1];
                MASINI->masini[j + 1] = aux;
            }
        }
    }
}



void sortare_model_descrescator(Repository* MASINI) {
    //Sorteaza masinile descrescator dupa model
    int n = MASINI->lungime;

    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (strcmp(get_model(&MASINI->masini[j]), get_model(&MASINI->masini[j + 1])) < 0) {
                Masina aux = MASINI->masini[j];
                MASINI->masini[j] = MASINI->masini[j + 1];
                MASINI->masini[j + 1] = aux;
            }
        }
    }
}
*/

int inchiriere(Repository* MASINI, char* numar) {
    //Marcheaza o masina ca fiind inchiriata, in cazul in care aceasta este disponibila
    int inchiriat = -1;
    for (int i = 0; i < MASINI->lungime; i++) {
        if (strcmp(MASINI->masini[i].numar, numar) == 0) {
            if (MASINI->masini[i].inchiriata == 0) {
                inchiriat = 1;
                MASINI->masini[i].inchiriata = 1;
            } else {
                inchiriat = 0;
            }
        }
    }
    return inchiriat;
}

int returnare(Repository* MASINI, char* numar) {
    //Marcheaza o masina ca fiind disponibila, in cazul in care aceasta este inchiriata
    int returnat = -1;
    for (int i = 0; i < MASINI->lungime; i++) {
        if (strcmp(MASINI->masini[i].numar, numar) == 0) {
            if (MASINI->masini[i].inchiriata == 1) {
                returnat = 1;
                MASINI->masini[i].inchiriata = 0;
            } else {
                returnat = 0;
            }
        }
    }
    return returnat;
}
