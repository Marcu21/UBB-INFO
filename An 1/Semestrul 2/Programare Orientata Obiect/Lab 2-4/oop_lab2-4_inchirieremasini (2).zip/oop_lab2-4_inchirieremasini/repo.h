#pragma once
#include "Domain.h"

typedef struct {
    Masina* masini;
    int lungime;
    int capacitate;
}Repository;

void init(Repository* masini);
void adaugareR(Repository* MASINI, Masina masina);
void actualizamR(Repository* MASINI, char* numar, char* categorie_noua, char* model_nou);
void distruge(Repository* masini);
Repository creeaza_vid();