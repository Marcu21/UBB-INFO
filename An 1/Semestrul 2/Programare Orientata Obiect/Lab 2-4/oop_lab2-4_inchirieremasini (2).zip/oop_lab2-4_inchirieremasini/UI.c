#include <crtdbg.h>
#include <stdio.h>
#include "Repo.h"
#include "Service.h"
#include "Domain.h"
#include "teste.h"
#include "validator.h"

void print_menu() {
    //Afiseaza pe ecran meniul pentru utilizator
    printf("\nAlege una dintre optiunile urmatoare: \n");
    printf("1.Adauga masina \n");
    printf("2.Actualizare masina\n");
    printf("3.Inchiriere/Returnare masina\n");
    printf("4.Vizualizare masina dupa criteriu\n");
    printf("5.Sortare masina dupa criteriu\n");
}

void afisare(Repository* MASINI) {
    //Afiseaza toate masinile din lista de masini
    for (int i = 0; i < MASINI->lungime; i++)
    {
        printf("Numar inmatriculare: %s\n", get_numar(&MASINI->masini[i]));
        printf("Categorie: %s\n", get_categorie(&MASINI->masini[i]));
        printf("Model: %s\n", get_model(&MASINI->masini[i]));
        if (MASINI->masini[i].inchiriata == 1) {
            printf("Stare: Inchiriata\n");
        } else {
            printf("Stare: Disponibila\n");
        }
    }
}
/*
void afisare_masini(Repository MASINI) {

    for (int i = 0; i < MASINI.lungime; i++)
    {
        printf("Numar inmatriculare: %s\n", get_numar(&MASINI.masini[i]));
        printf("Categorie: %s\n", get_categorie(&MASINI.masini[i]));
        printf("Model: %s\n", get_model(&MASINI.masini[i]));
        if (MASINI.masini[i].inchiriata == 1) {
            printf("Stare: Inchiriata\n");
        } else {
            printf("Stare: Disponibila\n");
        }
    }
}
*/


int main() {

    _CrtDumpMemoryLeaks();
    Repository MASINI;
    init(&MASINI);
    int optiune;

    ruleaza_toate_testele();

    int continua = 1;
    while (continua) {
        print_menu();
        printf("Introduceti optiunea: ");
        scanf("%d", &optiune);

        switch (optiune)
        {
            case 0:{
                afisare(&MASINI);
                break;
            }
            case 1: {
                char numar[20], categorie[20], model[20];
                printf("Introduceti numar inmatriculare: ");
                scanf("%s", numar);

                printf("Introduceti categorie: ");
                scanf("%s", categorie);

                printf("Introduceti model: ");
                scanf("%s", model);
                int ok;
                ok = adauga(&MASINI, numar, categorie, model);
                if (ok == -1) printf("Datele introduse pentru masina sunt invalide. Va rugam introduceti date valide.\n");
                else if (ok == 1) printf("Masina a fost adaugata cu succes! ");

                break;
            }
            case 2: {
                char numar[20];
                printf("Introduceti numarul de inmatriculare: ");
                scanf("%s", numar);
                char categorie_noua[20], model_nou[20];
                printf("Introdu noua categorie: ");
                scanf("%s", categorie_noua);

                printf("Introdu noul model: ");
                scanf("%s", model_nou);
                int ok;

                ok = actualizare(&MASINI, numar, categorie_noua, model_nou);
                if (ok == -1) printf("Datele introduse pentru masina sunt invalide. Va rugam introduceti date valide.\n");
                else if (ok == 1) printf("Masina a fost actualizata cu succes!");
                break;

            }
            case 3: {
                printf("1. Inchiriere masina\n2.Returnare masina");
                int opt = 0;
                scanf("%d", &opt);
                if (opt == 1)
                {
                    printf("Introdu numarul de inmatriculare: ");
                    char numar[20];
                    int inchiriat;
                    scanf("%s", numar);
                    inchiriat = inchiriere(&MASINI, numar);
                    if (inchiriat == 1) printf("Masina a fost inchiriata! ");
                    else if (inchiriat == 0) printf("Masina este deja inchiriata! ");
                    else if (inchiriat == -1) printf("Masina cu acest numar de inmatriculare nu exista! ");
                }
                else if (opt == 2)
                {
                    printf("Introdu numarul de inmatriculare: ");
                    char numar[20];
                    int returnat;
                    scanf("%s", numar);
                    returnat = returnare(&MASINI, numar);
                    if (returnat == 1) printf("Masina a fost returnata! ");
                    else if(returnat == 0) printf("Masina nu este inchiriata! ");
                    else if(returnat == -1) printf("Masina cu acest numar de inmatriculare nu exista! ");
                }
                else printf("Optiune invalida!");
                break;
            }
            case 4: {
                printf("1. Dupa categorie \n2. Dupa model \nIntrodu optiunea ta: ");
                int opt = 0;
                scanf("%d", &opt);
                if (opt == 1)
                {
                    printf("Introdu categoria: ");
                    char categorie[20];
                    scanf("%s", categorie);
                    afisare(vizualizare_categorie(&MASINI,categorie));
                }
                else if (opt == 2)
                {
                    printf("Introdu modelul: ");
                    char model[20];
                    scanf("%s", model);
                    afisare(vizualizare_model(&MASINI, model));
                }
                else printf("Optiune invalida! ");
                break;
            }
            case 5: {
                printf("1. Dupa categorie \n2. Dupa model \nIntrodu optiunea ta: ");
                int opt = 0;
                scanf("%d", &opt);
                if (opt == 1)
                {
                    printf("1. Crescator\n2.Descrescator\nIntrodu optiunea ta: ");
                    int opt2 = 0;
                    scanf("%d", &opt2);
                    if (opt2 == 1) {
                        sortare(&MASINI, comparator_categorie_crescator);
                        afisare(&MASINI);
                    }
                    else if (opt2 == 2) {
                        sortare(&MASINI, comparator_categorie_descrescator);
                        afisare(&MASINI);
                    }
                    else printf("Optiune invalida! ");
                }
                else if (opt == 2)
                {
                    printf("1. Crescator\n2.Descrescator\nIntrodu optiunea ta: ");
                    int opt2 = 0;
                    scanf("%d", &opt2);
                    if (opt2 == 1) {
                        sortare(&MASINI, comparator_model_crescator);
                        afisare(&MASINI);
                    }
                    else if (opt2 == 2) {
                        sortare(&MASINI, comparator_model_descrescator);
                        afisare(&MASINI);
                    }
                    else printf("Optiune invalida! ");
                }
                else printf("Optiune invalida! ");
                break;
            }
            case -1: {
                continua = 0;
                break;
            }
            default:
                break;
        }
    }

}