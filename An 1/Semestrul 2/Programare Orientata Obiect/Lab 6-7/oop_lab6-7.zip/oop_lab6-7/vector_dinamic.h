#pragma once

#include <stdexcept>

template <typename Element>
class IteratorVector;

template <typename Element>
class VectorDinamic
{
public:
    //constructor
    VectorDinamic();
    //constructor de copiere
    VectorDinamic(const VectorDinamic& obiect);
    //destructor
    ~VectorDinamic();
    VectorDinamic& operator=(const VectorDinamic& obiect);
    //move constructor
    void push_back(const Element& element);
    [[nodiscard]] int size() const noexcept;
    void erase(int poz);

    friend class IteratorVector<Element>;
    IteratorVector<Element> begin() const;
    IteratorVector<Element> end() const;

    Element& operator[](int index) const {
        //returneaza elementul de pe pozitia index (sa functioneze locatari[i])
        if (index < 0 || index >= dimensiune) {
            throw std::out_of_range("Index out of range");
        }
        return elemente[index];
    }

private:
    int dimensiune;
    int capacitate;
    Element* elemente;

    void redimensionare();
};

template <typename Element>

VectorDinamic<Element>::VectorDinamic() :elemente{ new Element[2] }, capacitate{ 2 }, dimensiune{ 0 }{
    //constructorul de initializare

}
template <typename Element>
VectorDinamic<Element>::VectorDinamic(const VectorDinamic& obiect) {
    //constructor de copiere
    elemente = new Element[obiect.capacitate];
    for (int i = 0; i < obiect.dimensiune; i++) {
        elemente[i] = obiect.elemente[i];
    }
    dimensiune = obiect.dimensiune;
    capacitate = obiect.capacitate;
}
template <typename Element>
VectorDinamic<Element>& VectorDinamic<Element>::operator=(const VectorDinamic& obiect)
{
    //operator de atribuire
    if (this == &obiect) {
        return *this;
    }
    delete[] elemente;
    elemente = new Element[obiect.capacitate];
    for (int i = 0; i < obiect.dimensiune; i++) {
        elemente[i] = obiect.elemente[i];
    }
    dimensiune = obiect.dimensiune;
    capacitate = obiect.capacitate;
    return *this;
}

template <typename Element>
void VectorDinamic<Element>::push_back(const Element& element)
{
    //adauga un element la sfarsitul vectorului
    redimensionare();
    elemente[dimensiune++] = element;
}

template <typename Element>
void VectorDinamic<Element>::erase(int pozitie)
{
    //sterge elementul de pe pozitia pozitie
    if (pozitie < 0 || pozitie >= dimensiune) return;
    for (int i = pozitie; i < dimensiune - 1; i++) {
        elemente[i] = elemente[i + 1];
    }
    dimensiune--;
}


template <typename Element>
int VectorDinamic<Element>::size() const noexcept {
    //returneaza dimensiunea vectorului
    return dimensiune;
}
template <typename Element>
void VectorDinamic<Element>::redimensionare()
{
    //redimensioneaza vectorul
    if (dimensiune < capacitate)
        return;
    capacitate *= 2;
    auto* auxiliar = new Element[capacitate];
    for (int i = 0; i < dimensiune; i++)
    {
        auxiliar[i] = elemente[i];
    }
    delete[] elemente;
    elemente = auxiliar;
}
template <typename Element>
VectorDinamic<Element>::~VectorDinamic() {
    //destructor
    delete[] elemente;
}


template <typename Element>
IteratorVector<Element> VectorDinamic<Element>::begin() const {
    //returneaza un iterator la inceputul vectorului
    return IteratorVector<Element>(*this);
}

template <typename Element>
IteratorVector<Element> VectorDinamic<Element>::end() const {
    //returneaza un iterator la sfarsitul vectorului
    return IteratorVector<Element>(*this, dimensiune);
}


template <typename Element>
class IteratorVector {
private:
    const VectorDinamic<Element>& vector;
    int pozitie = 0;
public:
    explicit IteratorVector(const VectorDinamic<Element>& vector) noexcept;
    IteratorVector(const VectorDinamic<Element>& vector, int pozitie) noexcept;
    Element& element()const;
    void urmator();
    Element& operator*();
    IteratorVector& operator++();
    bool operator==(const IteratorVector& obiect)noexcept;
    bool operator!=(const IteratorVector& obiect)noexcept;
};


template <typename Element>
IteratorVector<Element>::IteratorVector(const VectorDinamic<Element>& vector) noexcept : vector{ vector } {
    //constructor de initializare pentru iterator
}
template <typename Element>
IteratorVector<Element>::IteratorVector(const VectorDinamic<Element>& vector, int pozitie)  noexcept : vector{ vector }, pozitie{ pozitie }{
    //constructor de initializare pentru iterator
}


template <typename Element>
Element& IteratorVector<Element>::element() const {
    //returneaza elementul de pe pozitia respectiva
    return vector.elemente[pozitie];
}

template <typename Element>
void IteratorVector<Element>::urmator()
{
    //trece la urmatorul element
    pozitie++;
}

template <typename Element>
Element& IteratorVector<Element>::operator*()
{
    //returneaza elementul curent
    return element();
}

template <typename Element>
IteratorVector<Element>& IteratorVector<Element>::operator++()
{
    //trece la urmatorul element
    urmator();
    return *this;
}

template <typename Element>
bool IteratorVector<Element>::operator==(const IteratorVector& obiect)noexcept
{
    //verifica daca doi iteratori sunt egali
    return pozitie == obiect.pozitie;
}

template <typename Element>
bool IteratorVector<Element>::operator!=(const IteratorVector& obiect) noexcept {
    //verifica daca doi iteratori sunt diferiti
    return pozitie != obiect.pozitie;
}

