#include "locatar_repo.h"
#include "teste.h"
#include "ui.h"
int main() {
    ruleaza_toate_testele();
    locatar_repo repo;
    locatar_service service{ repo };
    UI ui{ service };
    ui.run();
    return 0;
}
