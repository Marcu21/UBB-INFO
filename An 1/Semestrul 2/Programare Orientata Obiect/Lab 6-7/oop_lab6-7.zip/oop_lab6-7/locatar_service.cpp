#include "locatar_service.h"
#include "locatar.h"
#include "validator.h"

void locatar_service::add(int apartament, const string& nume_proprietar, int suprafata, const string& tip_apartament){
    //Adauga un locatar daca este valid
    Locatar locatar;
    locatar = Locatar::creeaza_locatar(locatar, apartament, nume_proprietar, suprafata, tip_apartament);
    validator::validate_locatar(locatar);

    repo.store(locatar);
}

VectorDinamic<Locatar>& locatar_service::get_all() {
    return repo.get_all();
}


void locatar_service::sterge(int apartament, const string& nume_proprietar){
    //Sterge un locatar
    repo.destroy(apartament, nume_proprietar);
}

void locatar_service::modifica(int apartament, const string& nume_proprietar, int suprafata, const string& tip_apartament){
    //Modifica un locatar daca este valid
    Locatar locatar;
    locatar = Locatar::creeaza_locatar(locatar, apartament, nume_proprietar, suprafata, tip_apartament);
    validator::validate_locatar(locatar);
    repo.modify(apartament, nume_proprietar, suprafata, tip_apartament);
}

Locatar locatar_service::cauta(int apartament){
    //Cauta un locatar
    return repo.find(apartament);
}

VectorDinamic<Locatar> locatar_service::filtrare_tip(const string& tip_apartament){
    //Filtreaza locatarii dupa tipul apartamentului
    VectorDinamic<Locatar>& locatari = repo.get_all();
    VectorDinamic<Locatar> locatari_filtrate;
    for (const Locatar& locatar : locatari) {
        if (locatar.get_tip_apartament() == tip_apartament) {
            locatari_filtrate.push_back(locatar);
        }
    }
    return locatari_filtrate;}

VectorDinamic<Locatar> locatar_service::filtrare_suprafata(int suprafata){
    // Filtreaza locatarii dupa suprafata
    const VectorDinamic<Locatar>& locatari = repo.get_all();
    VectorDinamic<Locatar> locatari_filtrate;
    for (const Locatar& locatar : locatari) {
        if (locatar.get_suprafata() == suprafata) {
            locatari_filtrate.push_back(locatar);
        }
    }
    return locatari_filtrate;}



VectorDinamic<Locatar> locatar_service::sortare_nume_proprietar(){
    //Sorteaza locatarii dupa numele proprietarului
    VectorDinamic<Locatar>& locatari = repo.get_all();
    for (int i = 0; i < locatari.size() - 1; i++) {
        for (int j = i + 1; j < locatari.size(); j++) {
            if (locatari[i].get_nume_proprietar() > locatari[j].get_nume_proprietar()) {
                Locatar aux = locatari[i];
                locatari[i] = locatari[j];
                locatari[j] = aux;
            }
        }
    }
    return locatari;}

VectorDinamic<Locatar> locatar_service::sortare_suprafata(){
    //Sorteaza locatarii dupa suprafata
    VectorDinamic<Locatar>& locatari = repo.get_all();
    for (int i = 0; i < locatari.size() - 1; i++) {
        for (int j = i + 1; j < locatari.size(); j++) {
            if (locatari[i].get_suprafata() > locatari[j].get_suprafata()) {
                Locatar aux = locatari[i];
                locatari[i] = locatari[j];
                locatari[j] = aux;
            }
        }
    }
    return locatari;}

VectorDinamic<Locatar> locatar_service::sortare_tip_suprafata(){
    //Sorteaza locatarii dupa tipul apartamentului si suprafata
    VectorDinamic<Locatar>& locatari = repo.get_all();
    for (int i = 0; i < locatari.size() - 1; i++) {
        for (int j = i + 1; j < locatari.size(); j++) {
            if (locatari[i].get_tip_apartament() > locatari[j].get_tip_apartament()) {
                Locatar aux = locatari[i];
                locatari[i] = locatari[j];
                locatari[j] = aux;
            }
            else if (locatari[i].get_tip_apartament() == locatari[j].get_tip_apartament() && locatari[i].get_suprafata() > locatari[j].get_suprafata()) {
                Locatar aux = locatari[i];
                locatari[i] = locatari[j];
                locatari[j] = aux;
            }
        }
    }
    return locatari;}


