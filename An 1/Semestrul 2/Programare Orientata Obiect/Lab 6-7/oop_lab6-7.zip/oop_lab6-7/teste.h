#pragma once
void ruleaza_toate_testele();