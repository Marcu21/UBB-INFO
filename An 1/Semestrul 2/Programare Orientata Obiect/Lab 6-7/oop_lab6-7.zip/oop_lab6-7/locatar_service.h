#pragma once
#include <string>
#include "locatar.h"
#include "locatar_repo.h"
using std::string;

class locatar_service
{
private:
    locatar_repo& repo;
public:
    explicit locatar_service(locatar_repo& repo) :repo{ repo } {

    }
    //locatar_service(const locatar_service& service) = delete;
    //locatar_service() = default;
    void add(int apartament, const string& nume_proprietar, int suprafata, const string& tip_apartament);

    VectorDinamic<Locatar>& get_all();

    void sterge(int apartament, const string& nume_proprietar);

    void modifica(int apartament, const string& nume_proprietar, int suprafata, const string& tip_apartament);

    Locatar cauta(int apartament);

    VectorDinamic<Locatar> filtrare_tip(const string& tip_apartament);

    VectorDinamic<Locatar> filtrare_suprafata(int suprafata);

    VectorDinamic<Locatar> sortare_nume_proprietar();

    VectorDinamic<Locatar> sortare_suprafata();

    VectorDinamic<Locatar> sortare_tip_suprafata();
};
