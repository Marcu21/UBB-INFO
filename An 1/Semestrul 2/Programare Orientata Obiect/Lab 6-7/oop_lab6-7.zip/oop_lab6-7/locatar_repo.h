#pragma once
#include "vector_dinamic.h"
#include "locatar.h"


class locatar_repo
{
private:
    VectorDinamic<Locatar> locatari;
public:
    locatar_repo(const locatar_repo& repo) = delete;
    locatar_repo() = default;
    void store(const Locatar& locatar);
    VectorDinamic<Locatar>& get_all();
    void destroy(int apartament, const string& nume_proprietar);
    void modify(int apartament, const string& nume_proprietar, int suprafata, const string& tip_apartament);
    Locatar find(int apartament);
};
