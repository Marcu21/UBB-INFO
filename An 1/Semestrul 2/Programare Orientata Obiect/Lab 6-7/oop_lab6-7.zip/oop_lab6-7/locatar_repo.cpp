#include "locatar_repo.h"
#include "locatar.h"
#include "vector_dinamic.h"
#include "exception.h"


void locatar_repo::store(const Locatar& locatar) {
    //Adauga un locatar in lista de locatari
    for (const Locatar& l : locatari)
        if (l.get_apartament() == locatar.get_apartament() && l.get_nume_proprietar() == locatar.get_nume_proprietar())
            throw repo_exception("Locatar deja existent!");
    locatari.push_back(locatar);
}

VectorDinamic<Locatar>& locatar_repo::get_all(){
    //Returneaza lista de locatari
    return locatari;
}

void locatar_repo::destroy(int apartament, const string& nume_proprietar)
{
    // Sterge un locatar din lista de locatari
    for (int i = 0; i < locatari.size(); i++)
    {
        if (locatari[i].get_apartament() == apartament && locatari[i].get_nume_proprietar() == nume_proprietar)
        {
            locatari.erase(i);
            return;
        }
    }
    throw repo_exception("Locatar inexistent!");
}




void locatar_repo::modify(int apartament, const string& nume_proprietar, int suprafata, const string& tip_apartament) {
    //Modifica un locatar din lista de locatari
    for (auto& locatar : locatari) {
        if (locatar.get_apartament() == apartament) {
            locatar = Locatar::creeaza_locatar(locatar, apartament, nume_proprietar, suprafata, tip_apartament);
            return;
        }
    }
    throw repo_exception("Locatar inexistent!");
}


Locatar locatar_repo::find(int apartament)
{
    //Cauta un locatar dupa apartament
    for (const Locatar& locatar : locatari)
    {
        if (locatar.get_apartament() == apartament)
        {
            return locatar;
        }
    }
    throw repo_exception("Locatar inexistent!");
}