#pragma once
#include "locatar_service.h"
class UI
{
    locatar_service& service;
public:
    explicit UI(locatar_service& service) :service{ service } {

    }
    void run();
};