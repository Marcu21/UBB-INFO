#include "locatar_repo.h"
#include "teste.h"
#include "ui.h"
#include <iostream>
int main() {
    ruleaza_toate_testele();
    locatar_repo repo;
    locatar_service service{ repo };
    UI ui{ service };
    int optiune;
    printf("1. Program normal\n2. Lista notificari\n");
    std::cin>>optiune;
    if(optiune==1)
        ui.run();
    else if(optiune==2)
        ui.manage_notifications();
    else
        printf("Optiune invalida!\n");
    return 0;
}
