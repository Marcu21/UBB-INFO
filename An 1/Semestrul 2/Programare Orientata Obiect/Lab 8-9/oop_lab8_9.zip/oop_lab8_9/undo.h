#pragma once
#include "locatar.h"
#include "locatar_repo.h"
#include <memory>

class ActiuneUndo {
public:
    virtual void doUndo() = 0;
    virtual ~ActiuneUndo() = default;
};

class UndoAdauga : public ActiuneUndo {
    Locatar addedLocatar;
    locatar_repo& repo;

public:
    UndoAdauga(locatar_repo& repo, Locatar locatar)
            : addedLocatar(std::move(locatar)), repo(repo) {}


    void doUndo() override;
};

class UndoSterge : public ActiuneUndo {
    Locatar deletedLocatar;
    locatar_repo& repo;

public:
    UndoSterge(locatar_repo& repo, Locatar locatar)
            : repo(repo), deletedLocatar(std::move(locatar)) {}

    void doUndo() override;
};

class UndoModifica : public ActiuneUndo {
    Locatar oldLocatar;
    Locatar newLocatar;
    locatar_repo& repo;

public:
    UndoModifica(locatar_repo& repo, Locatar oldLoc, Locatar newLoc)
            : repo(repo), oldLocatar(std::move(oldLoc)), newLocatar(std::move(newLoc)) {}

    void doUndo() override;
};
