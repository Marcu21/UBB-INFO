#pragma once
#include "locatar.h"
#include <vector>

class locatar_repo
{
private:
    std::vector<Locatar> locatari;
public:
    locatar_repo(const locatar_repo& repo) = delete;
    locatar_repo() = default;
    void store(const Locatar& locatar);
    std::vector<Locatar>& get_all();
    void destroy(int apartament, const string& nume_proprietar);
    void modify(int apartament, const string& nume_proprietar, int suprafata, const string& tip_apartament);
    Locatar find(int apartament);
};
