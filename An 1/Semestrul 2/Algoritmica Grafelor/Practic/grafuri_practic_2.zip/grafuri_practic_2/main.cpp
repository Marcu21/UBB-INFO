#include <iostream>
#include <queue>
#include <unordered_map>
#include <vector>
#include <string>

struct Node{
    char ch;
    int freq;
    Node *left, *right;

    Node(char character, int frequency, Node *leftNode = nullptr, Node *rightNode = nullptr) : ch(character), freq(frequency), left(leftNode), right(rightNode) {}
};

struct Compare{
    bool operator()(Node* l, Node* r)
    {
        return l->freq > r->freq;
    }
};

void compresie(Node* rad, std::string sir, std::unordered_map<char, std::string> &huffmanCode)
{
    if (rad == nullptr) return;

    if (!rad->left && !rad->right) huffmanCode[rad->ch] = sir;

    compresie(rad->left, sir + "0", huffmanCode);
    compresie(rad->right, sir + "1", huffmanCode);
}

void decompresie(Node* rad, int &index, std::string sir)
{
    if (rad == nullptr) return;

    if (!rad->left && !rad->right)
    {
        std::cout << rad->ch;
        return;
    }

    index++;

    if (sir[index] == '0')
        decompresie(rad->left, index, sir);
    else
        decompresie(rad->right, index, sir);
}

int main()
{
    std::string text = "Treeaaassuureee";
    std::unordered_map<char, int> freq;
    for (char ch : text) freq[ch]++;

    std::priority_queue<Node*, std::vector<Node*>, Compare> pq;

    for (auto pair : freq) pq.push(new Node(pair.first, pair.second));

    while (pq.size() != 1)
    {
        Node *left = pq.top(); pq.pop();
        Node *right = pq.top(); pq.pop();

        int sum = left->freq + right->freq;
        pq.push(new Node('\0', sum, left, right));
    }

    Node* rad = pq.top();

    std::unordered_map<char, std::string> huffmanCode;
    compresie(rad,    "", huffmanCode);

    std::cout << "Codul Huffman:\n";
    for (auto pair : huffmanCode) std::cout << pair.first << " " << pair.second << "\n";

    std::string sir = "";
    for (char ch : text) sir += huffmanCode[ch];

    std::cout << "Compresia secventei:\n" << sir << "\n";

    int index = -1;
    std::cout << "Decompresia secventei:\n";
    while (index < (int)sir.size() - 1) decompresie(rad, index, sir);

    return 0;
}
