#include <iostream>
#include <fstream>

using namespace std;

#define MAX_SIZE 1000

int a[MAX_SIZE][MAX_SIZE] = {0}, e[MAX_SIZE] = {0};
int n, m, x, y, poz = 0;

void ciclu_euler(int k)
{
    for (int i = 0; i < n; i++)
        if (a[k][i] == 1)
        {
            a[k][i] = a[i][k] = 0;
            ciclu_euler(i);
        }
    e[++poz] = k;
}

int main() {
    ifstream fin("C:\\Users\\emanu\\CLionProjects\\grafuri_lab5_ex3\\fisier.txt");
    ofstream fout("C:\\Users\\emanu\\CLionProjects\\grafuri_lab5_ex3\\rezultat.txt");
    fin >> n >> m;
    for (int i = 0; i < m; i++)
    {
        fin >> x >> y;
        a[x][y] = a[y][x] = 1;
    }
    ciclu_euler(0);
    for (int i = 1; i < poz; i++) fout << e[i] << " ";
    fin.close();
    fout.close();
    return 0;
}