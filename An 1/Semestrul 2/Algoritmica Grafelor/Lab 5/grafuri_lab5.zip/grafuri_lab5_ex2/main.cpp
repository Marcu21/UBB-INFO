#include <iostream>
#include <vector>
#include <fstream>
#include <climits>

using namespace std;

const int MAX_SIZE = 1000;

int capacitate[MAX_SIZE][MAX_SIZE];
int flux[MAX_SIZE][MAX_SIZE];
int exces[MAX_SIZE];
int inaltime[MAX_SIZE];
vector<int> graf[MAX_SIZE];

int n, m;

void impinge(int x, int y)
{
    int delta = min(exces[x], capacitate[x][y] - flux[x][y]);
    flux[x][y] += delta;
    flux[y][x] -= delta;
    exces[x] -= delta;
    exces[y] += delta;
}

void reclasifica(int nod)
{
    int inaltime_min = INT_MAX;
    for (int vecin : graf[nod])
        if (capacitate[nod][vecin] - flux[nod][vecin] > 0) inaltime_min = min(inaltime_min, inaltime[vecin]);
    inaltime[nod] = inaltime_min + 1;
}

void descarca(int nod)
{
    while (exces[nod] > 0)
    {
        bool a_impins = false;
        for (int vecin : graf[nod]) {
            if (capacitate[nod][vecin] - flux[nod][vecin] > 0 && inaltime[nod] == inaltime[vecin] + 1)
            {
                impinge(nod, vecin);
                a_impins = true;
                if (exces[nod] == 0) break;
            }
        }
        if (!a_impins) reclasifica(nod);
    }
}

int flux_maxim(int sursa, int destinatie)
{
    inaltime[sursa] = n;
    exces[sursa] = INT_MAX;
    for (int vecin : graf[sursa]) impinge(sursa, vecin);

    bool progres = true;
    while (progres)
    {
        progres = false;
        for (int u = 0; u < n; u++)
        {
            if (u != sursa && u != destinatie && exces[u] > 0)
            {
                int inaltime_veche = inaltime[u];
                descarca(u);
                if (inaltime[u] > inaltime_veche) progres = true;
            }
        }
    }

    int flux_total = 0;
    for (int vecin : graf[sursa]) flux_total += flux[sursa][vecin];
    return flux_total;
}

int main() {
    ifstream fin("C:\\Users\\emanu\\CLionProjects\\grafuri_lab5_ex2\\fisier.in");
    ofstream fout("C:\\Users\\emanu\\CLionProjects\\grafuri_lab5_ex2\\fisier.out");
    fin >> n >> m;
    for (int i = 0; i < n; ++i)
    {
        for (int j = 0; j < n; ++j)
        {
            capacitate[i][j] = 0;
            flux[i][j] = 0;
        }
        exces[i] = 0;
        inaltime[i] = 0;
    }

    for (int i = 0; i < m; i++)
    {
        int u, v, c;
        fin >> u >> v >> c;
        if (capacitate[u][v] == 0 && capacitate[v][u] == 0)
        {
            graf[u].push_back(v);
            graf[v].push_back(u);
        }
        capacitate[u][v] += c;
    }

    int sursa = 0, destinatie = n - 1;
    int rezultat = flux_maxim(sursa, destinatie);
    fout << rezultat << endl;

    fin.close();
    fout.close();
    return 0;
}
