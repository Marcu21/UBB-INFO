#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

const int MAX_SIZE = 10000;

int n, m, cost[MAX_SIZE][MAX_SIZE], reziduri[MAX_SIZE][MAX_SIZE], viz[MAX_SIZE], pred[MAX_SIZE];
vector<int> graf[MAX_SIZE];

ifstream fin("C:\\Users\\emanu\\CLionProjects\\grafuri_lab5_ex1\\fisier.in");
ofstream fout("C:\\Users\\emanu\\CLionProjects\\grafuri_lab5_ex1\\fisier.out");

void citeste()
{
    int x, y, c;
    fin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        fin >> x >> y >> c;
        x++; y++;
        cost[x][y] = cost[x][y] + c;
        graf[x].push_back(y);
        graf[y].push_back(x);
    }
}

int bfs()
{
    for (int i = 0; i <= n; i++)
        viz[i] = 0;
    queue<int> coada;
    coada.push(1);
    viz[1] = 1;
    while (!coada.empty())
    {
        int curent = coada.front();
        for (int i = 0; i < graf[curent].size() && curent != n; i++)
        {
            int vecin = graf[curent][i];
            if (reziduri[curent][vecin] == cost[curent][vecin] || viz[vecin] == 1) continue;
            viz[vecin] = 1;
            coada.push(vecin);
            pred[vecin] = curent;
        }

        coada.pop();
    }
    return viz[n];
}

int edmonds_karp() {
    int nod, fmin, flux = 0;
    while (bfs() == 1)
    {
        for (int i = 0; i < graf[n].size(); i++)
        {
            int curent = graf[n][i];
            if (cost[curent][n] == reziduri[curent][n] || viz[curent] == 0)
                continue;
            pred[n] = curent;
            fmin = MAX_SIZE;
            for (nod = n; nod != 1; nod = pred[nod])
                fmin = min(fmin, cost[pred[nod]][nod] - reziduri[pred[nod]][nod]);
            if (fmin == 0)
                continue;
            for (nod = n; nod != 1; nod = pred[nod])
            {
                reziduri[pred[nod]][nod] = reziduri[pred[nod]][nod] + fmin;
                reziduri[nod][pred[nod]] = reziduri[nod][pred[nod]] - fmin;
            }
            flux = flux + fmin;
        }
    }
    return flux;
}

int main() {
    citeste();
    fout << edmonds_karp();
    fin.close();
    fout.close();
    return 0;
}