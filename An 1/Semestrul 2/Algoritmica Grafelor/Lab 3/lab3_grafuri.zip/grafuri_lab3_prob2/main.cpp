#include <iostream>
#include <fstream>
#include <vector>
#include <queue>

using namespace std;

#define INF 99999
int ok = 1;
struct Muchie {
    int sursa, destinatie, weight;
};

void johnson(const vector<vector<Muchie>>& graf, int V, vector<vector<int>>& distante)
{
    vector<Muchie> muchii;
    for (int i = 0; i < V; ++i) muchii.push_back({V, i, 0});
    vector<vector<Muchie>> graf_extins = graf;
    graf_extins.push_back(muchii);
    vector<int> h(V + 1, 0);
    for (int i = 0; i < V; ++i)
    {
        Muchie m = {V, i, 0};
        graf_extins[V].push_back(m);
    }
    vector<int> dist(V + 1, INF);
    dist[V] = 0;
    for (int i = 0; i < V; ++i)
        for (const auto& muchii : graf_extins)
            for (const auto& muchie : muchii)
                if (dist[muchie.sursa] != INF && dist[muchie.sursa] + muchie.weight < dist[muchie.destinatie])
                    dist[muchie.destinatie] = dist[muchie.sursa] + muchie.weight;
    for (const auto& muchii : graf_extins)
        for (const auto& muchie : muchii)
            if (dist[muchie.sursa] != INF && dist[muchie.sursa] + muchie.weight < dist[muchie.destinatie])
            {
                ok = -1;
                return;
            }
    for (int i = 0; i < V; ++i) h[i] = dist[i];
    distante.resize(V, vector<int>(V, INF));
    for (int u = 0; u < V; ++u)
    {
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;
        pq.push({0, u});
        distante[u][u] = 0;
        while (!pq.empty())
        {
            int dist_u = pq.top().first;
            int u = pq.top().second;
            pq.pop();
            if (dist_u > distante[u][u]) continue;
            for (const auto& muchie : graf[u])
            {
                int v = muchie.destinatie;
                int greutate = muchie.weight + h[u] - h[v];
                if (dist_u + greutate < distante[u][v])
                {
                    distante[u][v] = dist_u + greutate;
                    pq.push({distante[u][v], v});
                }
            }
        }
    }
}

int main(int argc, char* argv[])
{
    if (argc != 3) {
        cout << "Utilizare: " << argv[0] << " fisier intrare + fisier iesire" << endl;
        return 1;
    }
    ifstream fin(argv[1]);
    ofstream fout(argv[2]);
    int V, E;
    fin >> V >> E;
    vector<vector<Muchie>> graf(V);
    for (int i = 0; i < E; ++i)
    {
        int x, y, w;
        fin >> x >> y >> w;
        graf[x].push_back({x, y, w});
    }
    vector<vector<int>> distante;
    johnson(graf, V, distante);
    if (ok == -1) fout << "-1" << endl;
    else
        for (int i = 0; i < E; ++i)
            if (distante[0][i] == INF) fout << graf[i][0].sursa << " " << graf[i][0].destinatie << " INF" << endl;
            else fout << graf[i][0].sursa << " " << graf[i][0].destinatie << " " << distante[0][i] << endl;
        for (int i = 0; i < V; ++i)
        {
            for (int j = 0; j < V; ++j)
                if(distante[i][j] == INF) fout << "INF ";
                else fout << distante[i][j] << " ";
            fout << endl;
        }

    fin.close();
    fout.close();
    return 0;
}
