#include <iostream>
#include <fstream>
using namespace std;

#define maxim 99999
int n, m, x;
int matrice[999][999], distanta[999];
bool viza[999];

int distanta_minima()
{
    int min = maxim, min_index = 0;
    for (int i = 0; i < n; i++)
        if (!viza[i] && distanta[i] < min)
        {
            min = distanta[i];
            min_index = i;
        }
    return min_index;
}

void dijkstra(int sursa)
{
    for (int i = 0; i < n; i++)
        distanta[i] = maxim;
    distanta[sursa] = 0;
    for (int i = 0; i < n - 1; i++)
    {
        int u = distanta_minima();
        viza[u] = true;
        for (int v = 0; v < n; v++)
            if (!viza[v] && matrice[u][v] && (distanta[u] + matrice[u][v] < distanta[v]))
                distanta[v] = distanta[u] + matrice[u][v];
    }
}

int main(int argc, char** argv) {
    ifstream in(argv[1]);
    ofstream out(argv[2]);
    in >> n >> m >> x;
    int a, b, s;
    while (in >> a >> b >> s) matrice[a][b] = s;
    dijkstra(x);
    for (int i = 0; i < n; i++)
        if (distanta[i] == maxim) out << "INF"<< " ";
        else out << distanta[i] << " ";
    in.close();
    out.close();
    return 0;
}