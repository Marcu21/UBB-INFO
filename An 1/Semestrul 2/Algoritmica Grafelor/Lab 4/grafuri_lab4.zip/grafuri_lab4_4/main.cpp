#include <iostream>
#include <fstream>
#include <vector>
#include <queue>
#include <string>
#include <map>

using namespace std;

struct HuffmanNode{
    char ch;
    int freq;
    HuffmanNode* left;
    HuffmanNode* right;

    HuffmanNode(char caracter, int frecventa) : ch(caracter), freq(frecventa), left(nullptr), right(nullptr) {}
};


struct Compare{
    bool operator()(HuffmanNode* a, HuffmanNode* b)
    {
        if (a->freq == b->freq) return a->ch > b->ch;
        return a->freq > b->freq;
    }
};


void generate_back(priority_queue<HuffmanNode*, vector<HuffmanNode*>, Compare>& pq)
{
    while (pq.size() > 1)
    {
        HuffmanNode* left = pq.top(); pq.pop();
        HuffmanNode* right = pq.top(); pq.pop();

        HuffmanNode* parinte = new HuffmanNode('\0', left->freq + right->freq);
        parinte->left = left;
        parinte->right = right;
        pq.push(parinte);
    }
}

string decodare_huffman(HuffmanNode* radacina, const string& codat)
{
    string decodat = "";
    HuffmanNode* curent = radacina;
    for (char bit : codat)
    {
        if (bit == '0')
            curent = curent->left;
        else
            curent = curent->right;

        if (!curent->left && !curent->right)
        {
            decodat += curent->ch;
            curent = radacina;
        }
    }
    return decodat;
}

int main(int argc, char* argv[])
{
    if (argc != 3)
    {
        cerr << "Folosire: " << argv[0] << "<input_file> <output_file>" << endl;
        return 1;
    }

    ifstream fin(argv[1]);
    ofstream fout(argv[2]);

    int n;
    fin >> n;
    priority_queue<HuffmanNode*, vector<HuffmanNode*>, Compare> pq;
    char ch;
    int fr;

    for (int i = 0; i < n; i++)
    {
        fin >> ch >> fr;
        pq.push(new HuffmanNode(ch, fr));
    }

    generate_back(pq);

    string codat;
    fin >> codat;
    string decodat = decodare_huffman(pq.top(), codat);

    fout << decodat << endl;

    fin.close();
    fout.close();
    return 0;
}
