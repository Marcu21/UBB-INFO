#include <fstream>
#include <iostream>
#include <vector>
#include <queue>
#include <map>
#include <algorithm>

using namespace std;

struct HuffmanNode{
    char ch;
    int freq;
    HuffmanNode *left, *right;

    HuffmanNode(char caracter, int frecventa) : ch(caracter), freq(frecventa), left(nullptr), right(nullptr) {}
};

struct Compare{
    bool operator()(HuffmanNode* a, HuffmanNode* b) {
        if (a->freq == b->freq) return a->ch > b->ch;
        return a->freq > b->freq;
    }
};

void generate_cod(HuffmanNode* radacina, const string& str, map<char, string> &cod_huffman)
{
    if (!radacina) return;
    if (!radacina->left && !radacina->right) cod_huffman[radacina->ch] = str;
    generate_cod(radacina->left, str + "0", cod_huffman);
    generate_cod(radacina->right, str + "1", cod_huffman);
}

std::string readTextFromFile(const char* filename)
{
    std::ifstream file(filename);
    if (!file.is_open())
    {
        std::cerr << "Nu s-a putut deschide fisierul" << filename << std::endl;
        return "";
    }

    std::string text, line;
    while (std::getline(file, line)) text += line + "\n";
    file.close();

    if (!text.empty()) text.pop_back();

    return text;
}



void codare_huffman(const char* input, const char* output)
{
    ifstream fin(input);
    ofstream fout(output);

    string text = readTextFromFile(input);
    map<char, int> freq;
    for (char c : text) freq[c]++;

    priority_queue<HuffmanNode*, vector<HuffmanNode*>, Compare> pq;
    for (auto& pereche : freq) pq.push(new HuffmanNode(pereche.first, pereche.second));

    while (pq.size() != 1)
    {
        HuffmanNode *left = pq.top(); pq.pop();
        HuffmanNode *right = pq.top(); pq.pop();

        int suma = left->freq + right->freq;
        HuffmanNode *node = new HuffmanNode('\0', suma);
        node->left = left;
        node->right = right;
        pq.push(node);
    }

    HuffmanNode* radacina = pq.top();
    map<char, string> cod_huffman;
    generate_cod(radacina, "", cod_huffman);

    fout << freq.size() << endl;
    vector<pair<char, int>> sortedFreq(freq.begin(), freq.end());
    sort(sortedFreq.begin(), sortedFreq.end());
    for (auto& p : sortedFreq) fout << p.first << " " << p.second << endl;

    string codat;
    for (char c : text) codat += cod_huffman[c];
    fout << codat << endl;

    fin.close();
    fout.close();
}

int main(int argc, char* argv[])
{
    if (argc != 3)
    {
        cerr << "Folosire: " << argv[0] << "<input_file> <output_file>" << endl;
        return 1;
    }

    codare_huffman(argv[1], argv[2]);
    return 0;
}
