#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

const long long INF = 1e18;

int main(int argc, char* argv[])
{
    if (argc != 3)
    {
        cerr << "Folosire: " << argv[0] << "<input_file> <output_file>" << endl;
        return 1;
    }

    ifstream fin(argv[1]);
    ofstream fout(argv[2]);

    int V, E;
    fin >> V >> E;

    vector<vector<long long>> a(V, vector<long long>(V, INF));
    vector<long long> c(V, INF), t(V, -1);
    vector<bool> viz(V, false);

    for (int i = 0; i < E; i++)
    {
        int p, q;
        long long cost;
        fin >> p >> q >> cost;
        a[p][q] = cost;
        a[q][p] = cost;
    }

    c[0] = 0;
    t[0] = -1;

    long long cost_total = 0;
    vector<pair<int, int>> muchii;

    for (int count = 0; count < V; count++)
    {
        int min_c = -1;

        for (int i = 0; i < V; i++) {
            if (!viz[i] && (min_c == -1 || c[i] < c[min_c]))
            {
                min_c = i;
            }
        }

        viz[min_c] = true;
        cost_total += c[min_c];

        if (t[min_c] != -1) muchii.emplace_back(t[min_c], min_c);

        for (int i = 0; i < V; i++)
        {
            if (!viz[i] && a[min_c][i] < c[i])
            {
                c[i] = a[min_c][i];
                t[i] = min_c;
            }
        }
    }

    fout << cost_total << '\n';
    fout << muchii.size() << '\n';
    for (auto& edge : muchii) fout << edge.first << " " << edge.second << '\n';

    fin.close();
    fout.close();
    return 0;
}
