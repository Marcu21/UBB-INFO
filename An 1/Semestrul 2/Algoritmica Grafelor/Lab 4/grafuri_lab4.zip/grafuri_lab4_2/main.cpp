#include <fstream>
#include <iostream>

using namespace std;

const int MAX_N = 10000;

void decodare_prufer(const char* input, const char* output)
{
    ifstream fin(input);
    ofstream fout(output);

    int n, x;
    fin >> n;
    int nr_aparitii[MAX_N] = {0};
    int parinte[MAX_N];
    int cod_prufer[MAX_N];

    for (int i = 0; i < n; i++)
    {
        parinte[i] = -1;
        fin >> cod_prufer[i];
        nr_aparitii[cod_prufer[i]]++;
    }
    parinte[n] = -1;

    for (int i = 0; i < n; i++) {
        x = cod_prufer[i];
        int y = 0;
        while (y <= n && (nr_aparitii[y] > 0 || parinte[y] != -1)) y++;
        parinte[y] = x;
        nr_aparitii[x]--;
    }

    int ultim = 0;
    while (parinte[ultim] != -1) ultim++;
    parinte[ultim] = -1;

    fout << n + 1 << '\n';
    for (int i = 0; i <= n; i++) fout << parinte[i] << " ";
    fout << endl;

    fin.close();
    fout.close();
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        cerr << "Folosire: " << argv[0] << "<input_file> <output_file>" << endl;
        return 1;
    }

    decodare_prufer(argv[1], argv[2]);
    return 0;
}
