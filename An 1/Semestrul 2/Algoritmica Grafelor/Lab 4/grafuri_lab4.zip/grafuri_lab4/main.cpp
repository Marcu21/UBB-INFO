#include <iostream>
#include <fstream>

using namespace std;

int parinte[101], prufer[101];

int frunza_minima(int n)
{
    int minim = 0, i = 0;
    while (i < n)
    {
        if (minim == parinte[i])
        {
            minim++;
            i = -1;
        }
        i++;
    }
    return minim;
}

void codare_prufer(int n, const char* output)
{
    ofstream fout(output);
    for (int i = 0; i < n - 1; i++)
    {
        int minim = frunza_minima(n);
        prufer[i] = parinte[minim];
        parinte[minim] = minim;
    }

    fout << n - 1 << endl;
    for (int i = 0; i < n - 1; i++) fout << prufer[i] << " ";
    fout << endl;
    fout.close();
}

int main(int argc, char* argv[])
{
    if (argc != 3)
    {
        cerr << "Folosire: " << argv[0] << "<input_file> <output_file>" << endl;
        return 1;
    }

    ifstream fin(argv[1]);
    int n;
    fin >> n;
    for (int i = 0; i < n; i++) fin >> parinte[i];

    codare_prufer(n, argv[2]);

    fin.close();
    return 0;
}
