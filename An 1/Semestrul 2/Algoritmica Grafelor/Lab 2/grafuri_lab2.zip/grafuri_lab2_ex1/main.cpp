#include <stdio.h>

#define NMAX 100
#define INF 9999

int n;
int a[NMAX][NMAX];
int d[NMAX];
int p[NMAX];
bool viz[NMAX];

void citire()
{
    FILE *f = fopen("C:\\Users\\emanu\\CLionProjects\\grafuri_lab2_ex1\\graf.txt", "r");
    fscanf(f, "%d", &n);
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            a[i][j] = INF;
        }
    }
    int x, y;
    while (fscanf(f, "%d %d", &x, &y) != EOF)
    {
        a[x][y] = 1;
    }
    fclose(f);
}

void afisare() {
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            if (a[i][j] == INF)
            {
                printf("0 ");
            }
            else
            {
                printf("%d ", a[i][j]);
            }
        }
        printf("\n");
    }
}

void bfs(int s)
{
    for (int i = 1; i <= n; i++)
    {
        d[i] = INF;
        p[i] = 0;
        viz[i] = false;
    }
    d[s] = 0;
    viz[s] = true;
    int c[NMAX];
    int p1 = 1, p2 = 1;
    c[p1] = s;
    while (p1 <= p2)
    {
        int x = c[p1];
        p1++;
        for (int i = 1; i <= n; i++)
        {
            if (a[x][i] != INF && !viz[i])
            {
                d[i] = d[x] + 1;
                p[i] = x;
                viz[i] = true;
                p2++;
                c[p2] = i;
            }
        }
    }
}

void afisareLant(int s, int f)
{
    if (s == f)
    {
        printf("%d ", s);
    } else
    {
        afisareLant(s, p[f]);
        printf("%d ", f);
    }
}

int main()
{
    citire();
    afisare();
    int s;
    printf("Introduceti varful sursa: ");
    scanf("%d", &s);
    bfs(s);
    for (int i = 1; i <= n; i++)
    {
        if (i != s)
        {
            printf("Lantul de la %d la %d este: ", s, i);
            afisareLant(s, i);
            printf("\n");
        }
    }
    return 0;
}

