#include <iostream>
#include <fstream>

#define dimensiune 20

using namespace std;

ifstream f("C:\\Users\\emanu\\CLionProjects\\grafuri_lab2_ex2\\inchidere_tranzitiva.txt");

void afisare_matrice(int matr[dimensiune][dimensiune], int dim)
{
    for(int i = 1; i <= dim; i++)
    {
        for(int j = 1; j <= dim; j++) cout << matr[i][j] << " ";
        cout << endl;
    }
}

void matrice_inchidere_tranzitiva(int matr[dimensiune][dimensiune], int dim)
{
    for(int k = 1; k <= dim; k++)
        for(int i = 1; i <= dim; i++)
            for(int j = 1; j <= dim; j++)
                if(matr[i][j] == 0) matr[i][j] = matr[i][k] * matr[k][j];
}

int main()
{
    int n, m, matr[dimensiune][dimensiune] = {0};
    f >> n >> m;
    int a, b;
    for(int i = 0; i < m; i++)
    {
        f >> a >> b;
        matr[a][b] = 1;
    }
    cout << "matrice adiacenta:" << endl;
    afisare_matrice(matr, n);
    cout << "matrice inchidere tranzitiva:" << endl;
    matrice_inchidere_tranzitiva(matr, n);
    afisare_matrice(matr, n);

    f.close();
    return 0;
}
