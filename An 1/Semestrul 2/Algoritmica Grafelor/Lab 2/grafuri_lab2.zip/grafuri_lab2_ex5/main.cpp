#include <iostream>
#include <fstream>

#define NMAX 100
#define INF 9999

using namespace std;

int n;
int a[NMAX][NMAX];
bool viz[NMAX];

void citire()
{
    ifstream f("C:\\Users\\emanu\\CLionProjects\\grafuri_lab2_ex5\\graf.txt");
    f >> n;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            a[i][j] = INF;
        }
    }
    int x, y;
    while (f >> x >> y)
    {
        a[x][y] = 1;
    }
    f.close();
}

void afisare() {
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            if (a[i][j] == INF)
            {
                cout << "0 ";
            }
            else
            {
                cout << a[i][j] << " ";
            }
        }
        cout << endl;
    }
}

void dfs(int u)
{
    viz[u] = true;
    cout << u << " ";
    for (int v = 1; v <= n; v++)
    {
        if (a[u][v] == 1 && !viz[v])
        {
            dfs(v);
        }
    }
}

int main()
{
    citire();
    afisare();
    cout << "DFS: ";
    for (int i = 1; i <= n; i++)
    {
        if (!viz[i])
        {
            dfs(i);
        }
    }
    return 0;
}