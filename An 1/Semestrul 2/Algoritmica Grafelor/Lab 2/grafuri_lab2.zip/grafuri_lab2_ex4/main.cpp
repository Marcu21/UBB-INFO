#include <iostream>
#include <fstream>
#include <queue>

#define NMAX 100
#define INF 9999

using namespace std;

int n;
int a[NMAX][NMAX];
int d[NMAX];
int p[NMAX];
bool viz[NMAX];

void citire()
{
    ifstream f("C:\\Users\\emanu\\CLionProjects\\grafuri_lab2_ex4\\graf.txt");
    f >> n;
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            a[i][j] = INF;
        }
    }
    int x, y;
    while (f >> x >> y)
    {
        a[x][y] = 1;
    }
    f.close();
}

void afisare() {
    for (int i = 1; i <= n; i++)
    {
        for (int j = 1; j <= n; j++)
        {
            if (a[i][j] == INF)
            {
                cout << "0 ";
            }
            else
            {
                cout << a[i][j] << " ";
            }
        }
        cout << endl;
    }
}

void bfs(int s)
{
    for (int i = 1; i <= n; i++)
    {
        d[i] = INF;
        p[i] = 0;
        viz[i] = false;
    }
    d[s] = 0;
    viz[s] = true;
    queue<int> q;
    q.push(s);
    while (!q.empty())
    {
        int u = q.front();
        q.pop();
        for (int v = 1; v <= n; v++)
        {
            if (a[u][v] != INF && !viz[v])
            {
                d[v] = d[u] + 1;
                p[v] = u;
                viz[v] = true;
                q.push(v);
            }
        }
    }
}

void afisareLant(int s, int f)
{
    if (s == f)
    {
        cout << s << " ";
    }
    else if (p[f] == 0)
    {
        cout << "Nu exista drum de la " << s << " la " << f;
    }
    else
    {
        afisareLant(s, p[f]);
        cout << f << " ";
    }
}

int main()
{
    citire();
    afisare();
    int s;
    cout << "Introduceti varful sursa: ";
    cin >> s;
    bfs(s);
    for (int i = 1; i <= n; i++)
    {
        cout << "Distanta de la " << s << " la " << i << " este " << d[i] << endl;
    }
    for (int i = 1; i <= n; i++)
    {
        cout << "Drumul de la " << s << " la " << i << " este: ";
        afisareLant(s, i);
        cout << endl;
    }
    return 0;
}