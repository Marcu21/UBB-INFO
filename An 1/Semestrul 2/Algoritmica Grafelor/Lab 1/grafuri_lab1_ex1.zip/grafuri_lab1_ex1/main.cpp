#include <iostream>
#include <fstream>

using namespace std;

const int MAX_N = 100;
const int MAX_M = 100;

int main()
{
    ifstream fisier("C:\\Users\\emanu\\CLionProjects\\grafuri_lab1_ex1\\in.txt");
    if (!fisier.is_open())
    {
        cerr << "Nu s-a putut deschide fisierul!" << endl;
        return 1;
    }

    ofstream rezultat("C:\\Users\\emanu\\CLionProjects\\grafuri_lab1_ex1\\out.txt");
    if (!rezultat.is_open())
    {
        cerr << "Nu s-a putut deschide fisierul de iesire!" << endl;
        return 1;
    }

    int numarNoduri;
    fisier >> numarNoduri;
    cout << "Numarul de noduri: " << numarNoduri << endl;

    int listaAdiacenta[MAX_N * MAX_N] = {0};
    int matriceAdiacenta[MAX_N][MAX_N] = {0};
    int matriceIncidenta[MAX_N][MAX_M] = {0};

    cout << "Muchiile:" << endl;
    int nod1, nod2, indiceMuchie = 1;
    while (fisier >> nod1 >> nod2)
    {
        cout << nod1 << " " << nod2 << endl;
        rezultat << nod1 << " " << nod2 << endl;

        listaAdiacenta[(nod1 - 1) * numarNoduri + nod2 - 1] = 1;
        listaAdiacenta[(nod2 - 1) * numarNoduri + nod1 - 1] = 1;

        matriceAdiacenta[nod1][nod2] = 1;
        matriceAdiacenta[nod2][nod1] = 1;

        matriceIncidenta[nod1][indiceMuchie] = 1;
        matriceIncidenta[nod2][indiceMuchie] = 1;

        indiceMuchie++;
    }

    fisier.close();

    cout << "Matricea de adiacenta:\n";
    rezultat << "Matricea de adiacenta:\n";
    for (int i = 1; i <= numarNoduri; ++i)
    {
        for (int j = 1; j <= numarNoduri; ++j)
        {
            cout << matriceAdiacenta[i][j] << " ";
            rezultat << matriceAdiacenta[i][j] << " ";
        }
        cout << endl;
        rezultat << endl;
    }

    cout << "Lista de adiacenta:\n";
    rezultat << "Lista de adiacenta:\n";
    for (int i = 1; i <= numarNoduri; ++i)
    {
        cout << i << ": ";
        rezultat << i << ": ";
        for (int j = 1; j <= numarNoduri; ++j)
        {
            if (listaAdiacenta[(i - 1) * numarNoduri + j - 1] == 1)
            {
                cout << j << " ";
                rezultat << j << " ";
            }
        }
        cout << endl;
        rezultat << endl;
    }

    cout << "Matricea de incidenta:\n";
    rezultat << "Matricea de incidenta:\n";
    for (int i = 1; i <= numarNoduri; ++i)
    {
        for (int j = 1; j <= indiceMuchie - 1; ++j)
        {
            cout << matriceIncidenta[i][j] << " ";
            rezultat << matriceIncidenta[i][j] << " ";
        }
        cout << endl;
        rezultat << endl;
    }

    cout << "Lista de adiacenta:\n";
    rezultat << "Lista de adiacenta:\n";
    for (int i = 1; i <= numarNoduri; ++i)
    {
        cout << i << ": ";
        rezultat << i << ": ";
        for (int j = 1; j <= numarNoduri; ++j)
        {
            if (listaAdiacenta[(i - 1) * numarNoduri + j - 1] == 1)
            {
                cout << j << " ";
                rezultat << j << " ";
            }
        }
        cout << endl;
        rezultat << endl;
    }

    cout << "Matricea de adiacenta:\n";
    rezultat << "Matricea de adiacenta:\n";
    for (int i = 1; i <= numarNoduri; ++i)
    {
        for (int j = 1; j <= numarNoduri; ++j)
        {
            cout << matriceAdiacenta[i][j] << " ";
            rezultat << matriceAdiacenta[i][j] << " ";
        }
        cout << endl;
        rezultat << endl;
    }

    cout << "Lista de adiacenta:\n";
    rezultat << "Lista de adiacenta:\n";
    for (int i = 1; i <= numarNoduri; ++i)
    {
        cout << i << ": ";
        rezultat << i << ": ";
        for (int j = 1; j <= numarNoduri; ++j)
        {
            if (listaAdiacenta[(i - 1) * numarNoduri + j - 1] == 1)
            {
                cout << j << " ";
                rezultat << j << " ";
            }
        }
        cout << endl;
        rezultat << endl;
    }

    rezultat.close();

    return 0;
}
