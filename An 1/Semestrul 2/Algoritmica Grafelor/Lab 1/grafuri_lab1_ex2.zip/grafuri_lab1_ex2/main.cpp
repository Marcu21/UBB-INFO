#include <iostream>
#include <fstream>

using namespace std;

const int MAX_N = 100;

void noduriIzolate(int matriceAdiacenta[][MAX_N], int numarNoduri)
{
    int ok = 0;
    cout << "Noduri izolate: ";
    for (int i = 1; i <= numarNoduri; ++i)
    {
        int izolat = 1;
        for (int j = 1; j <= numarNoduri; ++j)
        {
            if (matriceAdiacenta[i][j] == 1 || matriceAdiacenta[j][i] == 1)
            {
                izolat = 0;
                break;
            }
        }
        if (izolat)
        {
            ok = 1;
            cout << i << " ";
        }
    }
    if (ok == 0) cout << "nu sunt noduri izolate. ";
    cout << endl;
}

int grafRegular(int matriceAdiacenta[][MAX_N], int numarNoduri)
{
    int grad = 0;
    for (int i = 1; i <= numarNoduri; ++i)
    {
        int gradNod = 0;
        for (int j = 1; j <= numarNoduri; ++j)
        {
            gradNod += matriceAdiacenta[i][j];
        }
        if (i == 1)
            grad = gradNod;
        else if (grad != gradNod)
            return 0;
    }
    return 1;
}

void matriceDistantelor(int matriceAdiacenta[][MAX_N], int numarNoduri)
{
    int matriceDistanta[MAX_N][MAX_N];
    for (int i = 1; i <= numarNoduri; ++i)
    {
        for (int j = 1; j <= numarNoduri; ++j)
        {
            if (i == j)
                matriceDistanta[i][j] = 0;
            else if (matriceAdiacenta[i][j] == 1)
                matriceDistanta[i][j] = 1;
            else
                matriceDistanta[i][j] = numarNoduri;
        }
    }
    for (int k = 1; k <= numarNoduri; ++k)
    {
        for (int i = 1; i <= numarNoduri; ++i)
        {
            for (int j = 1; j <= numarNoduri; ++j)
            {
                if (matriceDistanta[i][j] > matriceDistanta[i][k] + matriceDistanta[k][j])
                    matriceDistanta[i][j] = matriceDistanta[i][k] + matriceDistanta[k][j];
            }
        }
    }
    cout << "Matricea distantelor:\n";
    for (int i = 1; i <= numarNoduri; ++i)
    {
        for (int j = 1; j <= numarNoduri; ++j)
        {
            if (matriceDistanta[i][j] == numarNoduri)
                cout << "infinit";
            else
                cout << matriceDistanta[i][j] << " ";
        }
        cout << endl;
    }
}


int conex(int matriceAdiacenta[][MAX_N], int numarNoduri)
{
    int vizitat[MAX_N] = {0};
    int nodStart = 1;
    vizitat[nodStart] = 1;
    int noduriVizitate = 1;
    while (noduriVizitate < numarNoduri)
    {
        int gasit = 0;
        for (int i = 1; i <= numarNoduri; ++i)
        {
            if (matriceAdiacenta[nodStart][i] == 1 && !vizitat[i])
            {
                gasit = 1;
                vizitat[i] = 1;
                noduriVizitate++;
            }
        }
        if (!gasit)
        {
            for (int i = 1; i <= numarNoduri; ++i)
            {
                if (!vizitat[i])
                {
                    nodStart = i;
                    vizitat[nodStart] = 1;
                    noduriVizitate++;
                    break;
                }
            }
        }
    }
    for (int i = 1; i <= numarNoduri; ++i)
    {
        if (!vizitat[i])
            return 0;
    }
    return 1;
}

int main()
{
    ifstream fisier("C:\\Users\\emanu\\CLionProjects\\grafuri_lab1_ex2\\in.txt");
    if (!fisier.is_open())
    {
        cerr << "Nu s-a putut deschide fisierul!" << endl;
        return 1;
    }

    int numarNoduri;
    fisier >> numarNoduri;
    cout << "Numarul de noduri: " << numarNoduri << endl;

    int matriceAdiacenta[MAX_N][MAX_N] = {0};

    cout << "Muchiile:" << endl;
    int nod1, nod2;
    while (fisier >> nod1 >> nod2)
    {
        cout << nod1 << " " << nod2 << endl;

        matriceAdiacenta[nod1][nod2] = 1;
        matriceAdiacenta[nod2][nod1] = 1;
    }

    fisier.close();

    noduriIzolate(matriceAdiacenta, numarNoduri);

    if (grafRegular(matriceAdiacenta, numarNoduri))
        cout << "Graful este regular." << endl;
    else
        cout << "Graful nu este regular." << endl;

    matriceDistantelor(matriceAdiacenta, numarNoduri);

    if (conex(matriceAdiacenta, numarNoduri))
        cout << "Graful este conex." << endl;
    else
        cout << "Graful nu este conex." << endl;

    return 0;
}
